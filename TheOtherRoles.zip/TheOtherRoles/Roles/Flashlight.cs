//Flashlight Recently Not Available

/*
using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using Hazel;
using TheOtherRoles.Objects;
using TheOtherRoles.Patches;
using UnityEngine;

namespace TheOtherRoles
{
    [HarmonyPatch]
    public class Flashlight : RoleBase<Flashlight>
    {
        private static CustomButton flashlightButton;
        
        public static Color color = Palette.ImpostorRed;
        public static float cooldown { get { return CustomOptionHolder.flashlightCooldown.getFloat(); } }
        public static float duration { get { return CustomOptionHolder.flashlightDuration.getFloat(); } }
        public static bool nameblack { get { return CustomOptionHolder.flashlightNameBlack.getBool(); } }
        public static float flashTimer = 0f;

        public Flashlight()
        {
            RoleType = roleId =RoleType.Flashlight;
        }

        public static void startFlash()
        {
            flashTimer = duration;

            foreach (PlayerControl)
        }

        public override void OnMeetingStart()
        {
            
        }

        public static void MakeButtons(HudManger hm)
        {

            //Flashlight button
            flashlightButton = new CustomButton(
                () =>
                {
                    if (flashlightButton.isEffectActive)
                    {
                        flashlightButton.Timer = 0;
                        return;
                    }

                    MessageWriter writer = AmongUsClient.Instance.StartRpcImmediately(CachedPlayer.LocalPlayer.PlayerControl.NetId, (byte)CustomRPC.NinjaStealth, Hazel.SendOption.Reliable, -1);
                    writer.Write(CachedPlayer.LocalPlayer.PlayerControl.PlayerId);
                    writer.Write(true);
                    AmongUsClient.Instance.FinishRpcImmediately(writer);
                    RPCProcedure.ninjaStealth(CachedPlayer.LocalPlayer.PlayerControl.PlayerId, true);
                },
                () => { return CachedPlayer.LocalPlayer.PlayerControl.isRole(RoleType.Flashlight) && CachedPlayer.LocalPlayer.PlayerControl.isAlive(); },
                () =>
                {
                    if (flashlightButton.isEffectActive)
                    {
                        flashlightButton.buttonText = ModTranslation.getString("NinjaUnstealthText");
                    }
                    else
                    {
                        ninjaButton.buttonText = ModTranslation.getString("NinjaText");
                    }
                    return CachedPlayer.LocalPlayer.PlayerControl.CanMove;
                },
                () =>
                {
                    ninjaButton.Timer = ninjaButton.MaxTimer = Ninja.stealthCooldown;
                },
                Ninja.getButtonSprite(),
                new Vector3(-1.8f, -0.06f, 0),
                hm,
                hm.KillButton,
                KeyCode.F,
                true,
                Ninja.stealthDuration,
                () =>
                {
                    ninjaButton.Timer = ninjaButton.MaxTimer = Ninja.stealthCooldown;

                    MessageWriter writer = AmongUsClient.Instance.StartRpcImmediately(CachedPlayer.LocalPlayer.PlayerControl.NetId, (byte)CustomRPC.NinjaStealth, Hazel.SendOption.Reliable, -1);
                    writer.Write(CachedPlayer.LocalPlayer.PlayerControl.PlayerId);
                    writer.Write(false);
                    AmongUsClient.Instance.FinishRpcImmediately(writer);
                    RPCProcedure.ninjaStealth(CachedPlayer.LocalPlayer.PlayerControl.PlayerId, false);

                    CachedPlayer.LocalPlayer.PlayerControl.SetKillTimerUnchecked(Math.Max(CachedPlayer.LocalPlayer.PlayerControl.killTimer, Ninja.killPenalty));
                }
            )
            {
                buttonText = ModTranslation.getString("FlashlightText"),
                effectCancellable = true
            };
        }
    }
}*/